const routerConstants = {
  LOGIN: '/auth/login',
  REGISTRATION: '/auth/registration',
  FORGOT_PASSWORD: '/auth/forgotpassword',
  CONFIRM_MOBILE: '/auth/conformmobile',
};

export { routerConstants };
