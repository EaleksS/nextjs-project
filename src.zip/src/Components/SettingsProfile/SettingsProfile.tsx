import styles from "./SettingsProfile.module.scss";

type Props = {};

const SettingsProfile = (props: Props) => {
  return <div className={styles.settings_container}>ad</div>;
};

export default SettingsProfile;
