// export const BASE_URL = 'http://135.125.169.95:8090';
export const BASE_URL = 'http://localhost:8080';
