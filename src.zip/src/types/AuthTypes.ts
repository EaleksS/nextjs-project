export interface IUser {
  city: string;
  date_of_birth: string;
  email: string;
  firstname: string;
  isFirstLog: true;
  lastname: string;
  phone: string;
  role: string;
  state: string;
  username: string;
}
