import React from 'react';

const NotFound = () => {
  return (
    <div style={{ textAlign: 'center', marginTop: '100px' }}>
      404 - СТРАНИЦА НЕ НАЙДЕНА
    </div>
  );
};

export default NotFound;
