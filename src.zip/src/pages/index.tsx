import Layout from './Layout';
import Link from 'next/link';
import { routerConstants } from '@/Constants/RouterConstants';
import Main from './main';

export default function Home() {
  return (
    <>
      <Main />
    </>
  );
}
